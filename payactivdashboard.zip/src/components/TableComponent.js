import {
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow
  } from '@mui/material';

const TableComponent = ({search,data = []}) => {

  if (!data || data.length === 0) {  
    return <div> </div>;
  }

  const columns = Object.keys(data[0]);

    return(
      <TableContainer>
      <Table>
        <TableHead>
          <TableRow>
            {
                columns.map( (column,index) => (
                  <TableCell key={index} align="center" sx={{ fontWeight: 'bold', fontSize: '1rem' }}>
                      {column.charAt(0).toUpperCase() + column.slice(1)}
                  </TableCell>
                )
              )
            }
            {/*
            <TableCell align="center" sx={{fontWeight: 'bold', fontSize: '1rem' }}>Name</TableCell>
            <TableCell align="center" sx={{fontWeight: 'bold', fontSize: '1rem' }}>Email</TableCell>
            <TableCell align="center" sx={{fontWeight: 'bold', fontSize: '1rem' }}>Role</TableCell>*/}
          </TableRow>
        </TableHead>
        <TableBody>
          {data.filter((row) => {
            const searchTerm = search.toLowerCase();

              return (
                searchTerm === '' ||
                Object.values(row).some((value) => {
                  if (value !== undefined && value !== null) {
                    // Convert the value to a string and perform the search
                    return value.toString().toLowerCase().includes(searchTerm);
                  }
                return false;
              })
            );
          }).map((row, index) => (
            <TableRow key={index} hover>

              {
                columns.map(
                  (column,index) => 

                    <TableCell key={index} align="center" sx={{fontWeight: '500'}}>{row[column]}</TableCell>
          
                  )
              }
              {/*
              <TableCell align="center" sx={{fontWeight: '500'}}>{row.name}</TableCell>
              <TableCell align="center" sx={{fontWeight: '500'}}>{row.email}</TableCell>
              <TableCell align="center" sx={{fontWeight: '500'}}>{row.role}</TableCell>*/}

            </TableRow>

          ))}
        </TableBody>
      </Table>
    </TableContainer>
    );

}

export default TableComponent;