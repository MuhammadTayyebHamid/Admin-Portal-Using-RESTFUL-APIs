const Endpoints = {
    Organization: 'https://localhost:7019/api/Organization',
    Users: 'https://localhost:7019/api/Payment',
    Payments: 'https://localhost:7019/api/User'
};

export default Endpoints;